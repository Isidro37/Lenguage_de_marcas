    package es.isidro.tarea4_1.controller;

    import es.isidro.tarea4_1.model.Person;
    import es.isidro.tarea4_1.repositories.PersonRepository;
    import org.jeasy.random.EasyRandom;
    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.ui.Model;
    import org.springframework.web.bind.annotation.GetMapping;
    import org.springframework.web.bind.annotation.RequestMapping;
    import org.springframework.web.bind.annotation.RestController;

    import java.util.List;
    import java.util.stream.Collectors;



    @RestController
    @RequestMapping("/api")
    public class PersonRestController {
         @Autowired PersonRepository personRepository;

         @GetMapping("/persons")
        public Iterable<Person> getFincas()
         {
             return personRepository.findAll();
         }
         @GetMapping("/testnewpersons")
        public String testNewPersons(Model model){
             EasyRandom generator=new EasyRandom();
             List<Person> persons= generator.objects(Person.class, 5)
             .collect(Collectors.toList());
             for(Person p: persons)
            {
                 System.out.println(p);
                 personRepository.save(p);
             }
            return "Creado";
         }
    }
