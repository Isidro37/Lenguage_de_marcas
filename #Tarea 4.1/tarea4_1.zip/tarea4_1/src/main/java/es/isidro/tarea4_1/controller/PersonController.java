package es.isidro.tarea4_1.controller;

import es.isidro.tarea4_1.model.Person;
import es.isidro.tarea4_1.repositories.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class PersonController {
    @Autowired PersonRepository personRepository;

    @GetMapping("/person")
    public String getPerson(Model model){
        Person p = new Person();
        p.setName("Isidro");
        p.setSurname("García");
        model.addAttribute("person",p);
                return "person";
    }
    @GetMapping("/personlist")
    public String personList(Model model){
        model.addAttribute("persons",personRepository.findAll());
        return "personlist";
    }

    @GetMapping("/personform")
    public String personForm(Model model){
        model.addAttribute("person",new Person());
        return "personform";
    }

    @PostMapping("/saveperson")
    public String postParametro(@ModelAttribute("person") Person person, Model model){
        personRepository.save(person);
        return personList(model);
    }
}














