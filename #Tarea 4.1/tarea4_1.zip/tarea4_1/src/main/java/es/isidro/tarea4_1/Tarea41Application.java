package es.isidro.tarea4_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tarea41Application {

	public static void main(String[] args) {
		SpringApplication.run(Tarea41Application.class, args);
		System.out.println("http://localhost:8080/person");

	}

}
