<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejemplo PHP</title>
</head>

<body>
    <h1>PHP DE EJEMPLO</h1>
    <?php
    function procesarFormData($k, $v)
    {
        //$x = str_replace('item', '', $k);
        echo '<div><p>
                        <b>' . $k . '</b>
                         - <i>' . $v . '</i>
                      </p></div>';
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        foreach ($_POST as $key => $value) {
            procesarFormData($key, $value);
        }
    }

    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        foreach ($_GET as $key => $value) {
            procesarFormData($key, $value);
        }
    }
    ?>
</body>

</html>